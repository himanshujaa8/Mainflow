
    document.addEventListener("DOMContentLoaded", function () {
        const contactForm = document.getElementById("contact-form");

        contactForm.addEventListener("submit", function (e) {
            e.preventDefault();
            if (validateForm()) {
                
                alert("Form submitted successfully!");
                contactForm.reset();
            }
        });

        function validateForm() {
            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const message = document.getElementById("message").value;

            if (name.trim() === "" || email.trim() === "" || message.trim() === "") {
                alert("All fields are required.");
                return false;
            }

           

            return true;
        }
    });



    let slideIndex = 0;
    showSlides();

    function showSlides() {
        const slides = document.getElementsByClassName("mySlides");
        for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1;
        }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 1000);
    }


